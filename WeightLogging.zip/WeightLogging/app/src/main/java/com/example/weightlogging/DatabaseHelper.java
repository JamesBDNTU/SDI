package com.example.weightlogging;

import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.text.SimpleDateFormat;

import static android.content.ContentValues.TAG;


public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DB_NAME = "weight.db";
    public static final String TABLE_NAME = "WeightTable";
    public static final String COL1 = "Date";
    public static final String COL2 = "Weight";
    //assigns the names of the columns/tables/databases for use later on in the code

    SQLiteDatabase myDB;
    SimpleDateFormat SDateF = new SimpleDateFormat("dd MM yyyy");

    public DatabaseHelper(Context context){
        super(context, TABLE_NAME, null, 1);
    }

    @Override
    public void onCreate (SQLiteDatabase db){
        String createTable = "CREATE TABLE IF NOT EXISTS " + TABLE_NAME + "(" + COL1 + "TEXT UNIQUE NOT NULL, " + COL2 + " INTEGER)";
        db.execSQL(createTable);

    }

    @Override
    public void onUpgrade (SQLiteDatabase db, int i, int i1){
        //db.execSQL("DROP IF TABLE EXISTS " + TABLE_NAME);
        //onCreate(db);
        //not needed
    }

    public boolean addData(String date, String weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues conVal = new ContentValues();
        conVal.put(COL1, date);
        conVal.put(COL2, weight);
        long result = db.insert(TABLE_NAME, null, conVal);
        if (result == -1)
            return false;
        else
            return true;

    }

    public Cursor getAllData(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from " + TABLE_NAME, null);
        return res;

    }



}
