package com.example.weightlogging;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    DatabaseHelper myDB;
    Button b1, b2, b3, b4;
    //b1 - submit data, b2 - 1 week, b3 - 1 month, b4 - 3months
    EditText eDate, eWeight;
    //eDate - date enter, eWeight - weight enter
    TextView test1, test2;
    // test textviews to show data entered into SQLITe - used as a test - N O T permanent


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b1=(Button)findViewById(R.id.submit_Button);
        b2=(Button)findViewById(R.id.graph_Week);
        b3=(Button)findViewById(R.id.graph_Month);
        b4=(Button)findViewById(R.id.graph_3months);
        //assigning the variables to the ID in the display
        eDate=(EditText)findViewById(R.id.dateInput);
        eWeight=(EditText)findViewById(R.id.weightInput);
        //assigning variables to ID in display
        sqLiteTest();
    }

    public void addData() {
        b1.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        boolean isInserted = myDB.addData(eDate.getText().toString(),
                                eWeight.getText().toString() );
                        if (isInserted == true)
                            Toast.makeText(MainActivity.this,"Data inserted", Toast.LENGTH_LONG).show();
                        else
                            Toast.makeText(MainActivity.this,"Data not inserted", Toast.LENGTH_LONG).show();
                    }
                }
        );
    }

    public void sqLiteTest() {
        b2.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Cursor res = myDB.getAllData();
                        if(res.getCount() == 0){
                            showMessage("Error", "No Data");
                            return;
                        }

                        StringBuffer buffer = new StringBuffer();
                        while (res.moveToNext()) {
                            buffer.append("Date: "+ res.getString(0) + "\n");
                            buffer.append("Weight: "+ res.getString(1) + "\n\n");
                        }

                        //show all data
                        showMessage("Data", buffer.toString());
                    }
                }
        );

        test1=(TextView)findViewById(R.id.showText1);
        test2=(TextView)findViewById(R.id.showText2);


    }

    public void showMessage(String title, String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(Message);
        builder.show();
    }

}
